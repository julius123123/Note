const InvariantError = require("../../execptions/InvariantError");
const { NotePayloadSchema } = require("./schema")

const NotesValidator = {
    validateNotePayload: (payload) => {
        const validationResult = NotePayloadSchema.validate(payload);
        if (validationResult.error) {
            throw new InvariantError(validationResult.error.message);
        }
    }
    
}

module.exports = NotesValidator;